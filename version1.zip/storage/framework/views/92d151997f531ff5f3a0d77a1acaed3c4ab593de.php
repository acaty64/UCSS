<?php $__env->startSection('title','Crear Semestre'); ?>

<?php $__env->startSection('content'); ?>
	<?php echo Form::open(['route'=>'admin.semestres.store', 'method'=>'POST']); ?>


		<table>
			
			<tbody>
				<tr>
					<td><?php echo Form::label('semestre','Semestre'); ?>

						<?php echo Form::text('semestre', null, ['class'=>'form-control', 'placeholder'=>'Semestre','required']); ?>

					</td>
					<td>
						<?php echo Form::label('swactivo','Activo'); ?>

						<?php echo e(Form::hidden('swactivo', 0)); ?>

 						<?php echo e(Form::checkbox('swactivo', '1',0, ['class'=>'checkbox'] )); ?>

					</td>
				</tr>
				<tr>
					<td>
						<?php echo Form::label('inicio','inicio'); ?>

						<?php echo Form::text('inicio', null, ['class'=>'form-control','']); ?>

					</td>
					<td>
						<?php echo Form::label('fin','fin'); ?>

						<?php echo Form::text('fin', null, ['class'=>'form-control','']); ?>

					</td>
					<td>
						<?php echo Form::label('cierredisp','cierredisp'); ?>

						<?php echo Form::text('cierredisp', null, ['class'=>'form-control','']); ?>

					</td>
					<td>
						<?php echo Form::label('cierredata','cierredata'); ?>

						<?php echo Form::text('cierredata', null, ['class'=>'form-control','']); ?>

					</td>
				</tr>
			</tbody>
		</table>

		<div class="form-group">
			<?php echo Form::submit('Registrar', ['class'=>'btn btn-lg btn-primary']); ?>

		</div>
	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>