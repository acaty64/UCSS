<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	
	<hr>Estimado docente <?php echo e($wdocente); ?></hr>
	<hr><?php echo e($texto); ?> </hr>

	<hr>Fecha límite: <?php echo e($dlimite); ?> <?php echo e($flimite); ?></hr>
	<hr><a href="http://localhost:8000/login" >Acceda a la página haciendo click aquí.</a></hr>	
</body>
</html>