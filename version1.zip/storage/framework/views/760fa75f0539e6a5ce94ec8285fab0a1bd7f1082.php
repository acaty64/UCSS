<?php $__env->startSection('title','DATOS DE DOCENTE REGISTRADO'); ?>

<?php $__env->startSection('content'); ?>

<div class='subtitulo'>
	CONTENIDO DE DATOS
</div>
<hr style='color:blue'>

<div class='data'>
	Código de Docente: <?php echo e($view_user['username']); ?><br>
	<hr style='color:blue'>
	Apellido Paterno: <?php echo e($view_user['wdoc2']); ?><br>
	<hr style='color:blue'>
	Apellido Materno: <?php echo e($view_user['wdoc3']); ?><br>
	<hr style='color:blue'>
	Nombres: <?php echo e($view_user['wdoc1']); ?><br>
	<hr style='color:blue'>
	Celular: <?php echo e($datauser[0]['fono1']); ?><br>
	<hr style='color:blue'>
	Tfno.Fijo: <?php echo e($datauser[0]['fono2']); ?><br>
	<hr style='color:blue'>
	e-mail principal: <?php echo e($datauser[0]['email1']); ?><br>
	<hr style='color:blue'>
	e-mail secundario: <?php echo e($datauser[0]['email2']); ?><br>
	<hr style='color:blue'>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','pdf/usuario.blade.php'); ?>	



<?php echo $__env->make('template.A4_PDF', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>