<?php $__env->startSection('title','Disponibilidad Horaria del Docente: ' . $wdocente->wdocente($wdocente->id) ); ?>

<?php $__env->startSection('content'); ?>
	<?php echo Form::model($dhoras, array('route' => ['admin.dhoras.update', $dhoras->id], 'method' => 'PUT')); ?>

	<input type="hidden" name="user_id" value="<?php echo e($wdocente->id); ?>"></input>
	<input type="hidden" name="dhoras_id" value="<?php echo e($dhoras->id); ?>"></input>
	<table class="horario">
		<thead>
			<tr>
				<th><div class = 'horario-header'>LUNES</div></th>
				<th><div class = 'horario-header'>MARTES</div></th>
				<th><div class = 'horario-header'>MIÉRCOLES</div></th>
				<th><div class = 'horario-header'>JUEVES</div></th>
				<th><div class = 'horario-header'>VIERNES</div></th>
				<th><div class = 'horario-header'>SÁBADO</div></th>
			</tr>
		</thead>
		<tbody >
			<?php foreach($gfranjas as $gfranja): ?> 
				<tr class = 'horario-franja'>
					<?php for($i=1; $i < 7 ; $i++): ?>
						<td class = 'horario-dia'>
							<div id='cD<?php echo e($i); ?>_H<?php echo e($gfranja->turno); ?><?php echo e($gfranja->hora); ?>' class = 'horario-hora'>
							</div>
						</td>
					<?php endfor; ?>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<div class="form-group">
		<?php if( $sw_cambio == '1' ): ?>
			<?php echo Form::submit('Grabar modificaciones', ['class'=>'btn btn-primary']); ?>

		<?php else: ?>
			<p style="color:red">
				La fecha límite de modificación ha expirado. Si necesita modificar su disponibilidad comuníquese con la coordinación académica.
			</p>
		<?php endif; ?>
		<?php echo Form::close(); ?>

	</div>	
					
	<script	type="text/javascript">	
		<?php $ahoras = $dhoras->toArray() ?>
	
		<?php foreach	($franjas	as	$franja):	?>
			<?php	$xfranja	=	'D'.$franja->dia.'_H'.$franja->turno.$franja->hora;	?>			
			<?php	$xdiv 		=	'c'.$xfranja;	?>

//console.log("<?php echo e($xfranja); ?>");
			var 	container	=	document.getElementById("<?php echo e($xdiv); ?>");
			var checkbox = document.createElement('input');
			checkbox.type = "checkbox";
			checkbox.name = "<?php echo e($xfranja); ?>";
			checkbox.id = "<?php echo e($xfranja); ?>";

			check("<?php echo e($xfranja); ?>");
			var label = document.createElement('label');
			label.htmlFor = "<?php echo e($xfranja); ?>";
			label.appendChild(document.createTextNode("<?php echo e($franja->wfranja); ?>"));
			container.appendChild(checkbox);
			container.appendChild(label);
		<?php endforeach	?>

		function check( xfranja )
		{
//console.log("Franja: ",xfranja);
			<?php foreach ($ahoras as $xcampo => $value): ?>
//console.log( "Campo: ","<?php echo e($xcampo); ?>" );
				if("<?php echo e($xcampo); ?>" == xfranja)
				{
//console.log("Valor: ","<?php echo e($value); ?>");
					if("<?php echo e($value); ?>" == "1")
					{
//console.log("checked");
						checkbox.checked = 'checked';
					}
				}
			
			<?php endforeach ?>
		}
	</script>				
<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/dhoras/edit.blade.php'); ?>

<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>