<?php $__env->startSection('title','Cursos del grupo '.$cursos[0]->grupo->wgrupo); ?>

<?php $__env->startSection('content'); ?>
	<table class="table table-striped">
 		<thead>
 			<th>id</th>
 			<th>Código</th>
 			<th>Curso</th>
 			<th>Acción</th>
 		</thead>
 		<tbody>
 			<?php foreach($cursos as $curso): ?>
 				<tr>
	 				<td><?php echo e($curso->curso_id); ?></td>
	 				<td><?php echo e($curso->curso->ccurso); ?></td>
	 				<td><?php echo e($curso->curso->wcurso); ?></td>
	 				<td>
	 					<a href="<?php echo e(route('admin.grupocursos.orden', $curso->curso_id)); ?>" class="btn btn-warning" data-toggle="tooltip" title="Seleccionar" name="Seleccionar"><span class="glyphicon glyphicon-menu-right" aria-hidden='true'></span></a>
	 					<?php if($curso->sw_cambio == '0'): ?>
	 						<span style="Color:red">PENDIENTE</span>
	 					<?php else: ?> 
	 						<span style="Color:green">Actualizado</span>
	 					<?php endif; ?>
	 				</td>
	 			</tr>
 			<?php endforeach; ?>
 			
 		</tbody>
	</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/grupocursos/index.blade.php'); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>