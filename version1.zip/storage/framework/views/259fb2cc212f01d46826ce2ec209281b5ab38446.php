<?php $__env->startSection('title','Lista de Actualizaciones de Horas Disponibles'); ?>
dd($lista);
<?php $__env->startSection('content'); ?>
	<div>
		<a href="<?php echo e(route('admin.dhoras.Lista2Excel',array('lista'=>$lista,'namefile'=>$namefile))); ?>" class="btn btn-info">Exportar a Excel</a>
	</div>
	<table class="table table-striped">
 		<thead>
 			<th>Codigo</th>
 			<th>Docente</th>
 			<th>Envio</th>
 			<th>Limite</th>
 			<th>Actualizacion</th>
 			<th>Status</th>
 		</thead>
 		<tbody>
 			<?php foreach($lista as $registro): ?>
 				<tr>
 					<td><?php echo e($registro['username']); ?></td>
					<td><?php echo e(substr($registro['wdocente'],0,50)); ?></td>
					<td><?php echo e($registro['fenvio']); ?></td>
					<td><?php echo e($registro['flimite']); ?></td>
					<td><?php echo e($registro['updated_at']); ?></td>
					<td><?php echo e($registro['sw_actualizacion']); ?></td>
	 			</tr>
 			<?php endforeach; ?>
 			
 		</tbody>
	</table>
@endcontent
<?php $__env->startSection('view','admin/dhoras/lista.blade.php'); ?>

<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>