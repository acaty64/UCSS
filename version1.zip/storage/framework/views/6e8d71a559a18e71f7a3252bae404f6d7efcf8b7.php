<?php $__env->startSection('title','Lista de Semestres'); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('admin.semestres.create')); ?>" class="btn btn-info">Registrar Nuevo Semestre</a>
	<table class="table table-striped">
 		<thead>
 			<th>id</th>
 			<th>Semestre</th>
 			<th>Activo</th>
 			<th>Inicio</th>
 			<th>Fin</th>
 			<th>Cierre Dispon.</th>
 			<th>Cierre Datos</th>
 		</thead>
 		<tbody>
 			<?php foreach($semestres as $semestre): ?>
 				<tr>
	 				<td><?php echo e($semestre->id); ?></td>
	 				<td><?php echo e($semestre->semestre); ?></td>
	 				<td><?php echo e(Form::hidden('swactivo', 0)); ?>

	 					<?php echo e(Form::checkbox('swactivo', '1',$semestre->swactivo, ['class'=>'checkbox'] )); ?></td>
	 				<td><?php echo e($semestre->inicio); ?></td>
	 				<td><?php echo e($semestre->fin); ?></td>	
	 				<td><?php echo e($semestre->cierredisp); ?></td>	
	 				<td><?php echo e($semestre->cierredata); ?></td>		
	 				<td>
	 					<a href="<?php echo e(route('admin.semestres.edit', $semestre->id)); ?>" class="btn btn-warning"><span class="glyphicon glyphicon-wrench" aria-hidden='true'></span></a>

	 					<a href="<?php echo e(route('admin.semestres.destroy', $semestre->id)); ?>" onclick='return confirm("Está seguro de eliminar?")' class="btn btn-danger"><span class="glyphicon glyphicon-remove-circle" aria-hidden='true'></a>

	 				</td>
	 			</tr>
 			<?php endforeach; ?>
 			
 		</tbody>
	</table>
	<?php echo $semestres->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>