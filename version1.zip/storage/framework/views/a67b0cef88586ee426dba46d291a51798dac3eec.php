<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	
	<p>Estimado docente <?php echo e($wdocente); ?></p>
	<p></p>
	<p>Sírvase actualizar su disponibilidad horaria y de cursos en la siguiente dirección web: </p>
	<p><a href="http://localhost:8000/login" >Acceda a la página haciendo click aquí.</a></p>
	<p>Su código de acceso es su código de docente UCSS : <?php echo e($username); ?></p>
	<p>Su contraseña (password) de acceso es el número de su DNI.</p>
	<p>Fecha límite: <?php echo e($dlimite); ?> <?php echo e($flimite); ?></p>
	<p></p>
	<p>Ana C. Arashiro Tamashiro</p>
	<p>Coordinadora Académica de la Facultad de Ciencias Económicas y Comerciales</p>
	<p>Universidad Católica Sedes Sapientiae</p>

</body>
</html>