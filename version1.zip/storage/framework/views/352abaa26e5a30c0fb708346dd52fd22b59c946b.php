<?php $__env->startSection('title','Modificar Grupo de Cursos '.$grupo->wgrupo); ?>

<?php $__env->startSection('content'); ?>

	<?php echo Form::model($grupo, array('route' => array('admin.grupos.update', $grupo), 'method' => 'PUT')); ?>


		<div class="form-group">
			<?php echo Form::label('wgrupo','Descripción del Grupo'); ?>

			<?php echo Form::text('wgrupo', $grupo->wgrupo, ['class'=>'form-control', 'placeholder'=>'Ingrese la descripción del grupo','required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::submit('Grabar modificación de la descripción del grupo', ['class'=>'btn btn-primary']); ?>

		</div>

	<?php echo Form::close(); ?>


	<!-- MODIFICACION DE CURSOS DEL GRUPO -->
	<?php echo Form::open(['route' => ['admin.grupocursos.update', $grupo->id ], 'method'=>'PUT']); ?>


		<div class="form-group">
				<?php echo Form::select('cursos[]', $lcursos, $ch_cursos, ['multiple class'=>'chosen-select select-curso', 'multiple']); ?>

		</div>
			<?php echo Form::submit('Grabar modificaciones de los cursos del grupo', ['class'=>'btn btn-primary']); ?>

		</div>
	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script>
		$(".select-curso").chosen({
			placeholder_text_multiple:"Haga click aquí para seleccionar los cursos",
			width: "95%"
		}); 
	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/grupos/edit.blade.php'); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>