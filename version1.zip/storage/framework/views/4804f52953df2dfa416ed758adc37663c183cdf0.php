<?php $__env->startSection('title','Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
        <div class="col-md-4 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">Login</div>
	                <div class="panel-body">
						<?php echo Form::open(['route' => 'auth.login', 'method' => 'POST']); ?>

							 <?php echo csrf_field(); ?>

							<div>
								<?php echo Form::label('username','Código de Docente'); ?>

								<?php echo Form::text('username',null,['class'=>'form-control','placeholder'=>'000000','required']); ?> 
							</div>
							<div>
								<?php echo Form::label('password','Password'); ?>

								<?php echo Form::password('password',['class'=>'form-control','required' ]); ?>

							</div>
							<br>
							<!--div>
								<?php echo Form::checkbox('remember', false); ?> Recuérdame
							</div-->
							<br>
							<div>
								<?php echo Form::submit('Acceder', ['class' => 'btn btn-primary']); ?>

							</div>
						<?php echo Form::close(); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view','login'); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>