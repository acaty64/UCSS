<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo $__env->yieldContent('title','default'); ?></title>
	<!-- <?php echo Html::style('assets/css/estilos_pdf.css'); ?> -->
	<link href="css/estilos_pdf.css" rel="stylesheet" type="text/css" >
</head>
<body class='body'>
	<div class='titulo'><?php echo $__env->yieldContent('title'); ?></div>
	<hr style='color:blue'>
	<div class='contenido'>
		<?php echo $__env->yieldContent('content'); ?>
	</div>
	<footer class='footer'>
		<?php echo $__env->yieldContent('template.partials.footer_PDF'); ?>
	</footer>
</body>
</html>
