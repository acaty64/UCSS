Esta es la pagina horario.blade.php
