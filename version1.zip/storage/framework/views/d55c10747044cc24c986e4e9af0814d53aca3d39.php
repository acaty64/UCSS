<?php $__env->startSection('title','SILABO DEL CURSO: '.$wcurso); ?>

<?php $__env->startSection('content'); ?>
	<embed src= <?php echo e($arch_pdf); ?> width="100%" height="800" margin-left:auto margin-right:auto></embed>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','pdf/silabo.blade.php'); ?>	
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>