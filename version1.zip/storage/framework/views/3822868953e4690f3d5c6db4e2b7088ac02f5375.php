 
<?php $__env->startSection('title','Lista de Actualizaciones de Cursos Disponibles'); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('admin.dcursos.List2Excel')); ?>" class="btn btn-info">Exportar a Excel</a>
	<table class="table table-striped">
 		<thead>
 			<th>Codigo</th>
 			<th>Docente</th>
 			<th>Status</th>
 			<th>Envio</th>
 			<th>Limite</th>
 			<th>Actualizacion</th>
 			
 		</thead>
 		<tbody>
 			<?php foreach($lista as $registro): ?>
 				<tr>
 					<td><?php echo e($registro['username']); ?></td>
					<td><?php echo e(substr($registro['wdocente'],0,50)); ?></td>
					<td><?php echo e($registro['sw_actualizacion']); ?></td>
					<?php if($registro['status'] == 1): ?>
						<td><?php echo e($registro['fenvio']); ?></td>
						<td><?php echo e($registro['flimite']); ?></td>
						<td><?php echo e($registro['updated_at']); ?></td>
					<?php endif; ?>					
	 			</tr>
 			<?php endforeach; ?>
 		</tbody>
	</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/dcursos/list.blade.php'); ?>

<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>