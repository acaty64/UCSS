<?php $__env->startSection('title','Crear Nuevo Envío'); ?>

<?php $__env->startSection('content'); ?>

	<?php echo Form::open(['route'=>'admin.menvios.store', 'method'=>'POST']); ?>


		<div>
			<?php echo Form::label('tipo','Tipo'); ?>

			<?php echo Form::select('tipo',['disp'=>'Disponibilidad','hora'=>'Horarios Asignados','data'=>'Datos Usuarios'], null, ['class'=>'form-control', 'placeholder'=>'Seleccione el tipo','required']); ?>

		</div>
		<br>
		<div>
			<?php echo Form::label('flimite','Fecha límite'); ?>

			<?php echo Form::date('flimite', \Carbon\Carbon::now()); ?>

		</div>	
		<br>
		<div>
			<?php echo Form::label('tx_need','Asunto del correo'); ?>

			<?php echo Form::textarea('tx_need', null, ['class'=>'form-control', 'placeholder'=>'Ingrese el asunto (máximo 255 caracteres)','required']); ?>

		</div>
		<br>		
		<div class="form-group">
			<?php echo Form::submit('Grabar', ['class'=>'btn btn-lg btn-primary']); ?>

		</div>

	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/envios/create.blade.php'); ?>	
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>