<?php $__env->startSection('title','Lista de Docentes Comunicados. / Tipo: '
		. $Denvios[0]->menvio->tipo
		. ' / Fecha de Envío: ' . $Denvios[0]->menvio->fenvio
		. ' / Fecha Límite: ' . $Denvios[0]->menvio->flimite ); ?>

<?php $__env->startSection('content'); ?>

	<table class="table table-striped">
 		<thead>
 			<th>Id</th>
 			<th>Codigo</th>
 			<th>Docente Comunicado</th>
 			<th>Email enviado</th>
 			<th>Email con copia</th>
 			<th>Envío</th>
 			<th>Respuesta</th>
 		</thead>
 		<tbody>
 			<?php foreach($Denvios as $envio ): ?>
 				<tr>
 					<td><?php echo e($envio->id); ?></td>
 					<td><?php echo e($envio->user->username); ?></td>
 					<td><?php echo e(substr($envio->user->wdocente($envio->user_id),0,50)); ?></td>
 					<td><?php echo e($envio->email_to); ?></td>
 					<td><?php echo e($envio->email_cc); ?></td>
 					<td>
 						<?php if($envio->sw_envio == 1): ?>
 							<a href="#" class="btn btn-success" data-toggle="tooltip" title="Se envió"><span class="glyphicon glyphicon-ok" aria-hidden='true'></span></a>
 						<?php else: ?>
 							<a href="#" class="btn btn-danger" data-toggle="tooltip" title="Está pendiente de envío"><span class="glyphicon glyphicon-remove" aria-hidden='true'></span></a>
 						<?php endif; ?>

 					</td>
 					<td>
 						<?php if($envio->sw_rpta == 1): ?>
 							<a href="#" class="btn btn-success" data-toggle="tooltip" title="El docente respondió"><span class="glyphicon glyphicon-ok" aria-hidden='true'></span></a>
 						<?php else: ?>
 							<a href="#" class="btn btn-danger" data-toggle="tooltip" title="El docente no ha respondido"><span class="glyphicon glyphicon-remove" aria-hidden='true'></span></a>
 						<?php endif; ?>

 					</td>
	 			</tr>
 			<?php endforeach; ?> 			
 		</tbody>
	</table>
	<?php echo $Denvios->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/envios/list.blade.php'); ?>	

<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>