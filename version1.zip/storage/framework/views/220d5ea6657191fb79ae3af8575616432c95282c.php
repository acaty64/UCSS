<?php $__env->startSection('title','Grupo de Cursos'); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('admin.grupocursos.create')); ?>" class="btn btn-info">Crear Nuevo Grupo</a>
	<table class="table table-striped">
 		<thead>
 			<th>id</th>
 			<th>Código</th>
 			<th>Grupo</th>
 		</thead>
 		<tbody>
 			<?php foreach($grupocursos as $grupocurso): ?>
 				<tr>
	 				<td><?php echo e($grupocurso->grupo_id); ?></td>
	 				<td><?php echo e($grupocurso->cgrupo); ?></td>
	 				<td><?php echo e($grupocurso->grupo->wgrupo); ?></td>
	 				<td>
	 					<a href="<?php echo e(route('admin.grupocursos.edit', $grupocurso->grupo_id)); ?>" class="btn btn-warning" data-toggle="tooltip" title="Editar Grupo"><span class="glyphicon glyphicon-wrench" aria-hidden='true'></span></a>

	 					<a href="<?php echo e(route('admin.grupocursos.destroy', $grupocurso->grupo_id)); ?>" onclick='return confirm("Está seguro de eliminar?")' class="btn btn-danger" data-toggle="tooltip" title="Eliminar Grupo"><span class="glyphicon glyphicon-remove-circle" aria-hidden='true'></a>

	 				</td>
	 			</tr>
 			<?php endforeach; ?>
 			
 		</tbody>
	</table>
	<?php echo $grupocursos->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>