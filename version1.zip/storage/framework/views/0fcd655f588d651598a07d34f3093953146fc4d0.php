<?php $__env->startSection('title','Crear Usuario'); ?>

<?php $__env->startSection('content'); ?>

	<?php echo Form::open(['route'=>'admin.users.store', 'method'=>'POST']); ?>


		<div class="form-group">
			<?php echo Form::label('username','Código'); ?>

			<?php echo Form::text('username', null, ['class'=>'form-control', 'placeholder'=>'Código Docente','required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('password','Contraseña'); ?>

			<?php echo Form::password('password', ['class'=>'form-control', 'placeholder'=>'**********','required']); ?>

		</div>
		
		<div class="form-group">
			<?php echo Form::label('wdoc1','Nombres'); ?>

			<?php echo Form::text('wdoc1', null, ['class'=>'form-control', 'placeholder'=>'Ingrese sus Nombres','required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('wdoc2','Apellido Paterno'); ?>

			<?php echo Form::text('wdoc2', null, ['class'=>'form-control', 'placeholder'=>'Ingrese su Apellido Paterno','required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('wdoc3','Apellido Materno'); ?>

			<?php echo Form::text('wdoc3', null, ['class'=>'form-control', 'placeholder'=>'Ingrese su Apellido Materno','required']); ?>

		</div>
		
		<div class="form-group">
			<?php echo Form::label('type','Tipo'); ?>

			<?php echo Form::select('type',['01'=>'Administrativo','02'=>'Docente','03'=>'Responsable','09'=>'Master'], null, ['class'=>'form-control', 'placeholder'=>'Seleccione el tipo','required']); ?>

		</div>
		<br>
		<div class="form-group">
			<?php echo Form::submit('Registrar', ['class'=>'btn btn-lg btn-primary']); ?>

		</div>

	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/users/create.blade.php'); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>