<?php $__env->startSection('title','Importación de datos'); ?>

<?php $__env->startSection('content'); ?>

FALTA SUBIR EL ARCHIVO AL SERVIDOR /public/CSV

	<hr>
	<?php echo Form::open($tipos, array('route' => array('admin.import.updata', $tipos), 'method' => 'GET')); ?>

		<div class="form-group">
			<?php echo Form::label('tipo','Tipo'); ?>

			<?php echo Form::select('tipo',$tipos,null,['class'=>'form-control', 'placeholder'=>'Seleccione el tipo de archivo a importar','required']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::submit('Importar Datos', ['class'=>'btn btn-primary']); ?>

		</div>
	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('view','admin/import/index.blade.php'); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>