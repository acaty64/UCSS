<?php $__env->startSection('title','Designar Grupo Responsable '.$usergrupo->user->wdoc1." : Código ".$usergrupo->user->username); ?>

<?php $__env->startSection('content'); ?>
	<?php echo Form::model($usergrupo, array('route' => array('admin.usergrupos.update', $usergrupo->user_id), 'method' => 'PUT')); ?>

		<div class="form-group">	
			<?php echo Form::label('grupo','Designe el grupo: '); ?>

			<!-- Form::select('size', array('L' => 'Large', 'S' => 'Small'), 'S'); -->
			<?php echo Form::select('grupo', $grupos, $usergrupo->grupo_id, ['class'=>'form-control', 'placeholder'=> 'Seleccione el grupo asignado...', 'required']); ?>

		</div>	
		<div class="form-group">	
			<?php echo Form::submit('Grabar modificaciones', ['class'=>'btn btn-primary']); ?>

		</div>	

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/userGrupos/edit.blade.php'); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>