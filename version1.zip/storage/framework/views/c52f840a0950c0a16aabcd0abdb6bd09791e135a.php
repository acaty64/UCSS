<?php $__env->startSection('title','Página Principal'); ?>

<?php $__env->startSection('content'); ?>

CONTENIDO DE INICIO

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>