<?php $__env->startSection('title','Modificar Usuario '.$user->wdoc1." : Código ".$user->username); ?>

<?php $__env->startSection('content'); ?>

	<?php echo Form::model($user, array('route' => array('admin.users.savepass', $user->id), 'method' => 'PUT')); ?>


		<div class="form-group">
			<?php echo Form::label('password','Contraseña'); ?>

			<?php echo Form::password('password', ['class'=>'form-control', 'placeholder'=>'**********','required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('checkpassword','Confirme su Contraseña'); ?>

			<?php echo Form::password('checkpassword', ['class'=>'form-control', 'placeholder'=>'**********','required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::submit('Grabar nuevo password', ['class'=>'btn btn-primary']); ?>

		</div>

	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/users/chpass.blade.php'); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>