<?php $__env->startSection('title','Lista de Usuarios'); ?>

<?php $__env->startSection('content'); ?>
	<hr>
		<?php if(\Auth::user()->type =='09'): ?>
			<a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-info">Registrar Nuevo Usuario</a>
		<?php endif; ?>
		<!-- INICIO DEL BUSCADOR  -->
		<?php echo Form::open(['route' => 'admin.users.index', 'method'=>'GET', 'class'=>'navbar-form pull-right']); ?>

			<div class="input-group">
				<?php echo Form::text('wdocente', null, ['class'=>'form-control', 'placeholder'=>'Buscar docente...', 'aria-describedby'=>'search']); ?>

				<span class="input-group-addon" id='search'><span class="glyphicon glyphicon-search" "aria-hidden"="true"></span></span>
			</div>
		<?php echo Form::close(); ?>

	</hr>
	<!-- FIN DEL BUSCADOR -->
	<table class="table table-striped">
 		<thead>
 			<th>id</th>
 			<th>Código</th>
 			<th>Docente</th>
 			<th>Tipo</th>
 			<th>Acción</th>
 		</thead>
 		<tbody>
 			
 			<?php foreach($users as $user): ?>
 				<tr>
	 				<td><?php echo e($user->id); ?></td>
	 				<td><?php echo e($user->username); ?></td>
	 				<!--  ACTIVAR CUANDO SE MODIFIQUE DATA docentes <td><?php echo e($user->wDocente($user->id)); ?></td>-->
	 				<td><?php echo e(substr($user->wdocente($user->id),0,50)); ?></td>
	 				<td>
	 					<?php if($user->type == '01'): ?>
	 						<span class="label label-warning">Administrativo</span>
	 					<?php elseif($user->type == '02'): ?> 
	 						<span class="label label-success">Docente</span>
	 					<?php elseif($user->type =='03'): ?> 
	 						<span class="label label-danger">Responsable</span>
	 					<?php elseif($user->type == '09'): ?>
	 						<span class="label label-danger">Master</span>
	 					<?php endif; ?>
	 				</td>	
	 				<td>
	 					<?php if(\Auth::user()->type == '09'): ?>
		 					<a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-warning" data-toggle="tooltip" title="Modificar usuario"><span class="glyphicon glyphicon-wrench" aria-hidden='true'></span></a>

		 					<a href="<?php echo e(route('admin.users.editpass', $user->id)); ?>" class="btn btn-danger" data-toggle="tooltip" title="Modificar password"><span class="glyphicon glyphicon-lock" aria-hidden='true'></span></a>
		 					
		 					<a href="<?php echo e(route('admin.users.destroy', $user->id)); ?>" onclick='return confirm("Está seguro de eliminar el registro?")' class="btn btn-danger" data-toggle="tooltip" title="Eliminar usuario"><span class="glyphicon glyphicon-trash" aria-hidden='true'></a>

		 					<a href="<?php echo e(route('admin.datausers.edit', $user->id)); ?>" class="btn btn-success" data-toggle="tooltip" title="Modificar datos usuario"><span class="glyphicon glyphicon-earphone" aria-hidden='true'></span></a>

		 					<a href="<?php echo e(route('admin.dhoras.edit', $user->id)); ?>" class="btn btn-success" data-toggle="tooltip" title="Disponibilidad Horaria"><span class="glyphicon glyphicon-calendar" aria-hidden='true'></span></a>

		 					<a href="<?php echo e(route('admin.dcursos.edit', $user->id)); ?>" class="btn btn-success" data-toggle="tooltip" title="Disponibilidad de Cursos"><span class="glyphicon glyphicon-list-alt" aria-hidden='true'></span></a>
		 				<?php endif; ?>
	 					
	 					<a href="<?php echo e(route('PDF.usuario', $user->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Ver PDF" name="Ver PDF"><span class="glyphicon glyphicon-eye-open" aria-hidden='true'></span></a>
	 					<!--MODELO INVOICE Route::get('pdf', 'PdfController@invoice'); -->
	 					<!-- route('pdf', 'PDFController@invoice') -->
	 					<!-- a href="<?php echo e(route('pdf', 'PDFController@invoice')); ?>" class="btn btn-success">Invoice</a-->
	 					
	 				</td>
	 			</tr>
 			<?php endforeach; ?>
 			
 		</tbody>
	</table>
	<?php echo $users->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/users/index.blade.php'); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>