<?php $__env->startSection('title','Modificación de Datos del Docente: ' . $datauser->user->wdocente($datauser->user_id)); ?>

<?php $__env->startSection('content'); ?>
	<?php echo Form::model($datauser, array('route' => array('admin.datausers.update', $datauser->id), 'method' => 'POST')); ?>


		<div class="form-group">
			<?php echo Form::label('fono1','Teléfono Celular'); ?>

			<?php echo Form::number('fono1', $datauser->fono1, ['class'=>'form-control']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('fono2','Teléfono Fijo'); ?>

			<?php echo Form::number('fono2', $datauser->fono2, ['class'=>'form-control']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('email1','Correo Electrónico Principal'); ?>

			<?php echo Form::email('email1', $datauser->email1, ['class'=>'form-control', 'placeholder'=>'example@ucss.edu.pe']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('email2','Correo Electrónico Alternativo'); ?>

			<?php echo Form::email('email2', $datauser->email2, ['class'=>'form-control', 'placeholder'=>'example@gmail.com']); ?>

		</div>

		<div class="form-group">
			<tr>

			    <td>
					<?php echo Form::label('whatsapp','Marque la casilla si tiene instalado Whatsapp'); ?>

				</td>
				<td>
				<?php echo e(Form::hidden('whatsapp', 0)); ?>

				<?php if($datauser->whatsapp == 1): ?>			
					<?php echo Form::checkbox('whatsapp', 1, true, ['class'=>'checkbox', 'onclick' => 'javascript:evento(this);'] ); ?>

				<?php else: ?>
					<?php echo Form::checkbox('whatsapp', 0, false, ['class'=>'checkbox', 'onclick' => 'javascript:evento(this);'] ); ?>

				<?php endif; ?>
				</td>	
			</tr>
		</div>

		<div class="form-group">
			<?php echo Form::submit('Grabar modificaciones', ['class'=>'btn btn-primary']); ?>

			
		</div>
	<?php echo Form::close(); ?>

	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	function evento($obj){
		//console.log($obj);
		if($obj.checked)
			$obj.value = 1;
		else
			$obj.value = 0;
	}
</script>		
<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/datausers/edit.blade.php'); ?>	
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>