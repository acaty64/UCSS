<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo $__env->yieldContent('title','default'); ?>| Panel de Administración</title>
	<link rel="stylesheet" href="<?php echo e(asset('plugins\bootstrap\css\bootstrap.css')); ?>">

</head>
<body class='admin-body'>
	<?php echo $__env->make('admin.template.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<section class='section-admin'>
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<h3 class='panel-title'>
					<?php echo $__env->yieldContent('title'); ?>
				</h3>
			</div>	
		</div>
		<div class='panel-body'>
			<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('admin.template.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	</section>
	
	<script src="<?php echo e(asset('plugins\jquery\js\jquery-3.1.0.js')); ?>"></script>
	<script src="<?php echo e(asset('plugins\bootstrap\js\bootstrap.js')); ?>"></script>

	<footer class='admin.footer'>
		
	</footer>


</body>
</html>