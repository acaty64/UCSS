<?php $__env->startSection('title','Modificar Usuario '.$user->wdoc1." : Código ".$user->coduser); ?>

<?php $__env->startSection('content'); ?>

	<?php echo Form::model($user, array('route' => array('admin.users.update', $user->id), 'method' => 'PUT')); ?>


		<div class="form-group">
			<?php echo Form::label('wdoc1','Nombres'); ?>

			<?php echo Form::text('wdoc1', $user->wdoc1, ['class'=>'form-control', 'placeholder'=>'Ingrese sus Nombres','required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('wdoc2','Apellido Paterno'); ?>

			<?php echo Form::text('wdoc2', $user->wdoc2, ['class'=>'form-control', 'placeholder'=>'Ingrese su Apellido Paterno','required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('wdoc3','Apellido Materno'); ?>

			<?php echo Form::text('wdoc3', $user->wdoc3, ['class'=>'form-control', 'placeholder'=>'Ingrese su Apellido Materno','required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('type','Tipo'); ?>

			<?php echo Form::select('type', ['01'=>'Administrativo','02'=>'Docente','03'=>'Responsable','09'=>'Master'], $user->type, ['class'=>'form-control', 'required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::submit('Grabar modificaciones', ['class'=>'btn btn-primary']); ?>

		</div>

	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/users/edit.blade.php'); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>