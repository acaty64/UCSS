<?php $__env->startSection('title','Login en admin'); ?>

<?php $__env->startSection('content'); ?>
	<?php echo Form::open(['route' => 'admin.auth.login', 'method' => 'POST']); ?>

		<div>
			<?php echo Form::label('username','Código de Docente'); ?>

			<?php echo Form::text('username',null,['class'=>'form-control','placeholder'=>'000000','required']); ?> 
		</div>
		<div>
			<?php echo Form::label('password','Password'); ?>

			<?php echo Form::password('password',['class'=>'form-control','required' ]); ?>

		</div>

		<div>
			<?php echo Form::checkbox('remember', false); ?> Recuérdame
		</div>
			
		<div>
			<?php echo Form::submit('Acceder', ['class' => 'btn btn-primary']); ?>

		</div>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>