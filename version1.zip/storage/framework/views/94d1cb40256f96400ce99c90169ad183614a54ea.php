<?php $__env->startSection('title','Datos del Usuario'); ?>

/*<?php if(\App\DataUser->DataUser->id == null): ?>
{
	
	route('admin.DataUsers.edit', \App\DataUser->DataUser)
}*/

<?php $__env->startSection('content'); ?>
	
	<?php echo Form::open(['route'=>'admin.datausers.store', 'method'=>'POST']); ?>


		<div class="form-group">
			<?php echo Form::label('email1','email UCSS'); ?>

			<?php echo Form::email('email1', null, ['class'=>'form-control', 'placeholder'=>'example@gmail.ucss.pe','required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('email2','email personal'); ?>

			<?php echo Form::email('email2', null, ['class'=>'form-control', 'placeholder'=>'example@yahoo.com.pe','required']); ?>

		</div>



		<div class="form-group">
			<?php echo Form::submit('Registrar', ['class'=>'btn btn-primary']); ?>

		</div>

	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>