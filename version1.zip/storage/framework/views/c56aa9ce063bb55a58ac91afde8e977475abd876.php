<?php $__env->startSection('title','Grupo de Cursos'); ?>

<?php $__env->startSection('content'); ?>
	<a href="<?php echo e(route('admin.grupos.create')); ?>" class="btn btn-info">Crear Nuevo Grupo</a>
	<table class="table table-striped">
 		<thead>
 			<th>id</th>
 			<th>Código</th>
 			<th>Grupo</th>
 		</thead>
 		<tbody>
 			<?php foreach($grupos as $grupo): ?>
 				<tr>
	 				<td><?php echo e($grupo->id); ?></td>
	 				<td><?php echo e($grupo->cgrupo); ?></td>
	 				<td><?php echo e($grupo->wgrupo); ?></td>
	 				<td>
	 					<a href="<?php echo e(route('admin.grupos.edit', $grupo->id)); ?>" class="btn btn-warning" data-toggle="tooltip" title="Editar Grupo"><span class="glyphicon glyphicon-wrench" aria-hidden='true'></span></a>

	 					<a href="<?php echo e(route('admin.grupocursos.index', $grupo->id)); ?>" class="btn btn-warning" data-toggle="tooltip" title="Prioridad de Docentes"><span class="glyphicon glyphicon-sort" aria-hidden='true'></span></a>

	 					<a href="<?php echo e(route('admin.grupos.destroy', $grupo->id)); ?>" onclick='return confirm("Está seguro de eliminar el grupo?")' class="btn btn-danger" data-toggle="tooltip" title="Eliminar Grupo"><span class="glyphicon glyphicon-remove-circle" aria-hidden='true'></a>

	 				</td>
	 			</tr>
 			<?php endforeach; ?>
 			
 		</tbody>
	</table>
	<?php echo $grupos->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/grupos/index.blade.php'); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>