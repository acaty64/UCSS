<?php
header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
header("Content-Disposition: attachment;filename=result.xls ");
header("Content-Transfer-Encoding: binary ");
 
/*
http://www.lawebdelprogramador.com
*/
?>
 
<table border=0>
	<tr>
		<td style='font-weight:bold;font-size:1.3em;'>Gastos</td>
		<td style='font-size:1.2em; width:60px;'>2000</td>
		<td style='font-size:1.2em; width:60px;'>2001</td>
		<td style='font-size:1.2em; width:60px;'>2002</td>
	</tr>
	<tr>
		<td style='color:#00f;'>Viajes</td>
		<td>40,60</td>
		<td>43,40</td>
		<td>39,80</td>
	</tr>
	<tr>
		<td style='color:#00f'>Comidas</td>
		<td>6,5</td>
		<td>6,5</td>
		<td>3,3</td>
	</tr>
	<tr>
		<td style='color:#00f'>Alojamiento</td>
		<td>7,2</td>
		<td>7,8</td>
		<td>3,2</td>
	</tr>
	<tr>
		<td style='color:#00f'>Totales</td>
		<td style='background:#CFD2D8; border-top:1px solid; border-bottom:1px solid; border-left:1px solid;'>=suma(b2:b4)</td>
		<td style='background:#CFD2D8; border-top:1px solid; border-bottom:1px solid;'>=c2+c3+c4</td>
		<td style='background:#CFD2D8; border-top:1px solid; border-bottom:1px solid; border-right:1px solid;'>=suma(d2:d4)</td>
	</tr>
</table>