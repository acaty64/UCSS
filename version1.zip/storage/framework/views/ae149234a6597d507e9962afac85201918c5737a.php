<?php $__env->startSection('title','Prioridad de Docentes del curso '.$dcursos->first()->curso->wcurso); ?>

<?php $__env->startSection('content'); ?>
		<a href="<?php echo e(route('admin.grupocursos.index',$dcursos->first()->curso->grupocurso->grupo_id)); ?>" class="btn btn-info">Regresar al índice</a>
	<table class="table table-striped">
 		<thead>
 			<th>id</th>
 			<th>prioridad</th>
 			<th>Código</th>
 			<th>Curso</th>
 		</thead>
 		<tbody>
 			<?php foreach($dcursos as $dcurso): ?>
 				<tr>
	 				<td><?php echo e($dcurso->id); ?></td>
	 				<td><?php echo e($dcurso->prioridad); ?></td>
	 				<td><?php echo e($dcurso->user->username); ?></td>
	 				<td><?php echo e($dcurso->user->wdoc2); ?></td>
	 				<td>
						<a href="<?php echo e(route('admin.grupocursos.uporden', $dcurso->id)); ?>" name='<?php echo e($dcurso->prioridad); ?>' class="btn btn-success" data-toggle="tooltip" title="Subir"><span class="glyphicon glyphicon-menu-up" aria-hidden='true'></span></a>
						<a href="<?php echo e(route('admin.grupocursos.downorden', $dcurso->id)); ?>" class="btn btn-danger" data-toggle="tooltip" title="Bajar" onclick="javascript:evento_down(this);"><span class="glyphicon glyphicon-menu-down" aria-hidden='true'></span></a>
	 				</td>
	 			</tr>
 			<?php endforeach; ?>
 			
 		</tbody>
	</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/grupocursos/orden.blade.php'); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>