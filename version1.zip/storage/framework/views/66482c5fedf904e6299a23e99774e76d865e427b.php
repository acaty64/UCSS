<?php $__env->startSection('title','Grupos de Envios de Correos Electrónicos'); ?>

<?php $__env->startSection('content'); ?>
		<a href="<?php echo e(route('admin.menvios.create')); ?>" class="btn btn-info">Crear nuevo grupo de envios de correos electrónicos</a>
	<table class="table table-striped">
 		<thead>
 			<th>Id</th>
 			<th>Tipo</th>
 			<th>Fecha de envio</th>
 			<th>Fecha límite</th>
 			<th>Envíos</th>
 			<th>Respuestas</th>
 			<th>Acción</th>
 		</thead>
 		<tbody>
 			<?php foreach($Menvios as $envio ): ?>
 				<tr>
 					<td>
 						<?php echo e($envio->id); ?>

 					</td>
 					<td>
 						<?php echo e($envio->tipo); ?>

 					</td>
 					<td>
 						<?php echo e($envio->fenvio); ?>

 					</td>
 					<td>
 						<?php echo e($envio->flimite); ?>

 					</td>
 					<td>
 						 <span class="badge"><?php echo e($envio->envios); ?></span>
 					</td>
 					<td>
 						<span class="badge"><?php echo e($envio->rptas); ?></span>
 					</td>
	 				<td>
	 					<?php if($envio->sw_envio == 0): ?>
	 						<a href="<?php echo e(route('admin.menvios.edit', $envio->id)); ?>" class="btn btn-warning" data-toggle="tooltip" title="Modificar envio"><span class="glyphicon glyphicon-wrench" aria-hidden='true'></span></a>
	 						<a href="<?php echo e(route('admin.menvios.dshow', $envio->id )); ?>" class="btn btn-success" data-toggle="tooltip" title="Agregar Docentes a Comunicar"><span class="glyphicon glyphicon-plus-sign" aria-hidden='true'></span></a>
	 					<?php else: ?>
	 						<a href="<?php echo e(route('admin.menvios.show', $envio->id )); ?>" class="btn btn-primary" data-toggle="tooltip" title="Ver Docentes Comunicados"><span class="glyphicon glyphicon-eye-open" aria-hidden='true'></span></a>
	 					<?php endif; ?>
	 					<a href="<?php echo e(route('admin.menvios.destroy', $envio->id)); ?>" onclick='return confirm("Está seguro de eliminar este envio?")' class="btn btn-danger" data-toggle="tooltip" title="Eliminar envio"><span class="glyphicon glyphicon-trash" aria-hidden='true'></a>
	 					<?php if($envio->envios != 0 and $envio->sw_envio == 0): ?>
	 						<a href="<?php echo e(route('admin.envios.send', $envio->id)); ?>" class="btn btn-success" data-toggle="tooltip" title="Enviar los correos electrónicos"><span class="glyphicon glyphicon-send" aria-hidden='true'></a>
	 						<!-- a href="<?php echo e(route('admin.envios.testsend')); ?>" class="btn btn-danger" data-toggle="tooltip" title="TEST Enviar los correos electrónicos"><span class="glyphicon glyphicon-send" aria-hidden='true'></a -->
	 					<?php endif; ?>
	 				</td>
	 						
	 			</tr>
 			<?php endforeach; ?> 			
 		</tbody>
	</table>
	<?php echo $Menvios->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/envios/index.blade.php'); ?>	
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>