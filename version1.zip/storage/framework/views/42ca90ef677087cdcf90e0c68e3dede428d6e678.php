<?php $__env->startSection('title','Responsables'); ?>

<?php $__env->startSection('content'); ?>

	<table class="table table-striped">
 		<thead>
 			<th>id</th>
 			<th>Código</th>
 			<th>Docente</th>
 			<th>Grupo</th>
 			<th>Acción</th>
 		</thead>
 		<tbody>
 			<?php foreach($users as $user): ?>
 				<tr>
	 				<td><?php echo e($user->id); ?></td>
	 				<td><?php echo e($user->username); ?></td>
	 				<td><?php echo e($user->wdoc1); ?></td>
	 				<td><?php if(empty($user->usergrupo->grupo->wgrupo)): ?>	
	 						<div class='label label-danger'>ASOCIE UN GRUPO</div>
	 					<?php else: ?> 
	 						<div class='label label-success'><?php echo e($user->usergrupo->grupo->wgrupo); ?></div>
	 					<?php endif; ?>
	 				</td>
	 				<!-- BOTONES -->
	 				<td>
	 					<a href="<?php echo e(route('admin.usergrupos.edit', $user)); ?>" class="btn btn-warning"><span class="glyphicon glyphicon-plus" aria-hidden='true' data-toggle="tooltip" title="Asociar o Modificar Grupo"></span></a>
	 					<?php if(!empty($user->usergrupo->grupo->wgrupo)): ?>
	 						<a href="<?php echo e(route('admin.usergrupos.destroy', $user->id)); ?>" onclick='return confirm("Está seguro de eliminar?")' class="btn btn-danger" data-toggle="tooltip" title="Disociar grupo"><span class="glyphicon glyphicon-remove-circle" aria-hidden='true'></a>
	 					<?php endif; ?>

	 				</td>
	 			</tr>
 			<?php endforeach; ?>
 			
 		</tbody>
	</table>
	<?php echo $users->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('view','admin/userGrupos/index.blade.php'); ?>
<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>