<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
		
	<p>*********** EN CONSTRUCCION ****************</p>


	<p>Estimado docente <?php echo e($wdocente); ?></p>
	<p></p>
	<p></p>
	<p></p>
	<p></p>
	<p></p>
	<p></p>
	<p></p>
	<p>Ana C. Arashiro Tamashiro</p>
	<p>Coordinadora Académica de la Facultad de Ciencias Económicas y Comerciales</p>
	<p>Universidad Católica Sedes Sapientiae</p>

</body>
</html>