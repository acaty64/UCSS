<span style="font-size:75%; color:blue">
	<div >Universidad Católica Sedes Sapientiae</div>
	<div>Facultad de Ciencias Económicas y Comerciales</div>
	<div>Tfno. 533-0008 anexo 250</div>
</span>
